/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief  XMEGA SPI driver header file.
 *
 *      This file contains the function prototypes and enumerator definitions
 *      for various configuration parameters for the XMEGA SPI driver.  The
 *		code is intended to support both interrupt-driven (transceived) and
 *		supervised (blocking) transfers.
 *
 * \par Documentation
 *      For comprehensive code documentation, supported compilers, compiler
 *      settings and supported devices see readme.html
 *
 * \author
 *      California Optical Engineering: http://www.calopten.com \n
 *      Support email: 
 *
 * $Revision: 666 $
 * $Date: 2010-07-16 $  \n
 *
 * Copyright (c) 2009, California Optical Engineering
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
#ifndef AVRX_SPI_H
#define AVRX_SPI_H

#include <stdlib.h>
#include <avr/io.h>

#define _MAX_SPIQ 				512
#define _SPI_TX_DONE			0x01
#define _SPI_TX_BUSY			0x02
#define _SPI_TX_OVF				0x04
//#define _SPI_RX_DONE			0x08	// set when termination sequence detected
#define _SPI_RX_OVF 			0x10	// set when buffer overflows
#define _SPI_TX_INT				0x20	// this is the flag to indicate when another
										// master has taken over the bus - SPI will be disabled
//#define _SPI_RX_ON				0x20
#define _SPI_ERROR				0x80

#define _BIG_ENDIAN				0x00
#define _LITTLE_ENDIAN			0x40
										// leading edge		trailing edge
#define _SPI_MODE_0				0x00	// rising, sample	falling, set
#define _SPI_MODE_1				0x04	// rising, set		falling, sample
#define _SPI_MODE_2				0x08	// falling, sample	rising, set
#define _SPI_MODE_3				0x0C	// falling, set		rising, sample

#define _SPI_CLK_2				0x80	// these values are coded so that U2X = upper nibble
#define _SPI_CLK_4				0x00	// pre = lower nibble (as in datasheet)
#define _SPI_CLK_8				0x81
#define _SPI_CLK_16				0x01
#define _SPI_CLK_32				0x82
#define _SPI_CLK_64				0x02
#define _SPI_CLK_128			0x03

#define _SPI_INT_OFF			0x00
#define _SPI_INT_LO				0x01
#define _SPI_INT_MED			0x02
#define _SPI_INT_HI				0x03

#define _SPI_ENABLE				0x40

#define _SPI_PORTC				0xC0
#define _SPI_PORTD				0xD0
#define _SPI_PORTE				0xE0
#define _SPI_PORTF				0xF0

/* Hardware defines */

#define SPI_SS_bm             0x10 /*!< \brief Bit mask for the SS pin. */
#define SPI_MOSI_bm           0x20 /*!< \brief Bit mask for the MOSI pin. */
#define SPI_MISO_bm           0x40 /*!< \brief Bit mask for the MISO pin. */
#define SPI_SCK_bm            0x80 /*!< \brief Bit mask for the SCK pin. */

/* SPI master status code defines. */

#define SPI_OK              0     /*!< \brief The transmission completed successfully. */
#define SPI_INTERRUPTED     1     /*!< \brief The transmission was interrupted by another master. */
#define SPI_BUSY            2     /*!< \brief The SPI module is busy with another transmission. */
#define SPI_ERROR			3    /*!< \brief An error ocurred during transmission. */	

/*! \brief Enumerated data type for setting the endianness of SPI transfers */
typedef enum {
	SPI_BIG_ENDIAN = _BIG_ENDIAN,
	SPI_LITTLE_ENDIAN = _LITTLE_ENDIAN
} byteOrder;

/*! \brief Enumerated data type for setting the SPI mode of the interface */
typedef enum {
	SPIMODE0 = _SPI_MODE_0,
	SPIMODE1 = _SPI_MODE_1,
	SPIMODE2 = _SPI_MODE_2,
	SPIMODE3 = _SPI_MODE_3
} spiDataMode;

/*! \brief Enumerated data type for setting the clock rate of the master SPI */
typedef enum {
	SPICLK2   = _SPI_CLK_2,		/*!< \brief sets the SPI clock to peripheral clock/2 */
	SPICLK4   = _SPI_CLK_4,		/*!< \brief sets the SPI clock to peripheral clock/4 */
	SPICLK8   = _SPI_CLK_8,		/*!< \brief sets the SPI clock to peripheral clock/8 */
	SPICLK16  = _SPI_CLK_16,	/*!< \brief sets the SPI clock to peripheral clock/16 */
	SPICLK32  = _SPI_CLK_32,	/*!< \brief sets the SPI clock to peripheral clock/32 */
	SPICLK64  = _SPI_CLK_64,	/*!< \brief sets the SPI clock to peripheral clock/64 */
	SPICLK128 = _SPI_CLK_128	/*!< \brief sets the SPI clock to peripheral clock/128 */
} spiClkPre;

/*! \brief Enumerated data type for setting the interrupt level of the SPI interface */
typedef enum {
	SPIINTOFF  = _SPI_INT_OFF,
	SPIINTLO   = _SPI_INT_LO,
	SPIINTMED  = _SPI_INT_MED,
	SPIINTHI   = _SPI_INT_HI
} spiIntLvl;


/*! \brief SPI master struct. Holds pointer to SPI module, buffers and necessary variables. */
typedef struct SPI_Master
{
	register8_t *rDATA, *rSTATUS, *rCTRL, *rINTCTRL;	/*!< \brief SPI register addresses */
	register8_t *rDIR, *rOUT, *rSSCTRL;					/*!< \brief Port register addresses for SS control. */
	volatile uint8_t SPI_State; 						/*!< \brief state variable for SPI master. */
	volatile uint16_t nQlen; 							/*!< \brief Number of bytes to transfer. */
	volatile uint16_t nBytesNow; 						/*!< \brief Number of bytes transferred. */
	volatile uint8_t  fSlaveMask;						/*!< \brief Mask indicating which slaves are active. */
	volatile uint8_t  nCurSlave;						/*!< \brief Indicator of currently selected slave. */
	volatile char *TxData;        						/*!< \brief Pointer to data to transmit. */
	volatile char *RxData;      						/*!< \brief Pointer to where to store received data. */

} SPI_Master_t;


/*! \brief SPI slave struct. Holds pointers to SPI module and used port. */
typedef struct SPI_Slave
{
	register8_t *rDATA, *rSTATUS, *rCTRL, *rINTCTRL;	/*!< \brief SPI register addresses */
	register8_t *rDIR, *rOUT, *rSSCTRL;					/*!< \brief Port register addresses for SS sensing */
	volatile uint8_t SPI_State; 						/*!< \brief state variable for SPI slave */
	volatile char *TxData; 								/*!< \brief Pointer to data to transmit */
	volatile char *RxData;								/*!< \brief Pointer to where to store received data. */
	volatile uint16_t TxQlen, TxQnow, RxQlen, RxQnow;

} SPI_Slave_t;


// prototype functions

/*! \brief Initialize SPI module as master.
 *
 *  This function initializes a SPI module as master. The CTRL and INTCTRL
 *  registers for the SPI module is set according to the inputs to the function.
 *  In addition, data direction for the MOSI and SCK pins is set to output.
 *
 *  \param spi          The SPI_Master_t struct instance (poor-man's C++)
 *  \param module       The SPI module with SFR addresses
 *  \param port         The I/O port where the SPI module is connected (for SS control)
 *  \param dataOrd      Data order is _BIG_ENDIAN or _LITTLE_ENDIAN
 *  \param spiMode      SPI mode (Clock polarity and phase)
 *  \param spiPre  		SPI clock prescaler divison factor.
 *  \param intLvl     	SPI interrupt level
 */
int8_t SPIM_Init(SPI_Master_t *spi, uint8_t nSPI, uint8_t fSlaves , byteOrder dataOrd,
				spiDataMode spiMode, spiClkPre spiPre, spiIntLvl intLvl, uint8_t bufSz);

/*! \brief Initialize SPI module as slave.
 *
 *  This function initializes a SPI module as slave. The CTRL and INTCTRL
 *  registers for the SPI module is set according to the inputs to the function.
 *  In addition, data direction for the MISO pin is set to output.
 *
 *  \param spi          The SPI_Slave_t instance.
 *  \param module       Pointer to the SPI module.
 *  \param port         The I/O port where the SPI module is connected.
 *  \param dataOrd      Data order is _BIG_ENDIAN or _LITTLE_ENDIAN
 *  \param spiMode      SPI mode (Clock polarity and phase) 
 *  \param intLvl       SPI interrupt level.
 */
int8_t SPIS_Init(SPI_Slave_t *spi, uint8_t nSPI, byteOrder dataOrd,
				spiDataMode spiMode, spiIntLvl intLvl, uint8_t bufSz);


/*! \brief Change mode of SPI transfer (SPIM_Mode)
 *
 *  This function changes the SPI interface data mode.  The four modes are:
 *   -# Mode 0 = leading edge rising, sample	trailing edge falling, set
 *   -# Mode 1 = leading edge rising, set	trailing edge falling, sample
 *   -# Mode 2 = leading edge falling, sample	trailing edge rising, set
 *   -# Mode 3 = leading edge falling, set	trailing edge rising, sample
 *
 *  \param spi				  Pointer to the modules own SPI_Master_t struct.
 *  \param mode				  The mode to set the interface to
 *
 *	\note	For convenience, the enumerated type spiDataMode is used in this 
 *  function
 */
void SPIM_Mode(SPI_Master_t *spi, spiDataMode mode);

/*! \brief Common SPI master interrupt service routine.
 *
 *  This function is called by the SPI interrupt service handlers. For each
 *  SPI module that uses this driver, the ISR should call this function with
 *  a pointer to the related SPI_Master_t struct as argument.
 *
 *  \param spi        Pointer to the modules own SPI_Master_t struct.
 */
void SPIM_Handler(SPI_Master_t *spi);

/*! \brief SPI master interrupt service routine.
 *
 *  The interrupt service routines calls one common function,
 *  SPIM_Handler(SPI_Master_t *spi),
 *  passing information about what module to handle.
 *
 *  \param SPIn_INT_vect	Appropriate SPI_vect for the port used
 *							(e.g. master on PORTC = SPIC_INT_vect)
 *	\param <spiMaster>		Name of SPI Master instance
 *							(note: MUST be instantiated, NOT SPI_Master_t *spiMaster)
 *
 *  ISR(SPIn_INT_vect)
 *	{
 *		SPIM_Handler(&<spiMaster>);
 *	}
 */

/*! \brief SPIM_Send (start transaction using interrupts)
 *
 *  This function starts an SPI transmission. The SPI interface must be 
 *  initialized to turn interrupt handling on, and an ISR must be instantiated.
 *
 *  \param *spi               pointer to the SPI_Master_t struct instance.
 *  \param slave			  mask to indicate which slave(s) the data should be sent to
 *	\param len				  the number of bytes to transceive
 *	\param *tx				  pointer to instantiated buffer that holds Tx data
 *	\param *rx				  pointer to instantiated buffer that holds Rx data
 *
 *  \return                   Status code
 *  \retval SPI_OK            The transmission was completed successfully.
 *  \retval SPI_BUSY          The SPI module is busy.
 *  \retval SPI_INTERRUPTED   The transmission was interrupted by another master.
 */
uint8_t SPIM_Send(SPI_Master_t *spi, uint8_t slave, uint8_t len, char *tx, char *rx);


/*! \brief SPIM_Transceive (non-interrupt transaction)
 *
 *  This function transceives a number of bytes contained in a data packet
 *  struct. The SS line is kept low until all bytes are transceived. The
 *  received bytes are stored in the rx data pointer.
 *
 *  \param spi				SPI_Master_t struct instance.
 *  \param slave			slave(s) to send data to 
 *	\param len				number of bytes to transceive
  *	\param *tx				pointer to instantiated buffer that holds Tx data
  *	\param *rx				pointer to instantiated buffer that holds Rx data
*
 *  \return            Whether the function was successfully completed
 *  \retval true	   Success
 *  \retval false	   Failure
 */
uint8_t SPIM_Transceive(SPI_Master_t *spi, uint8_t slave, uint8_t len, char *tx, char *rx);

/*! \brief SPI slave interrupt service routine.
 *
 *  There is no real need for a SPIS_Handler, so this function
 *  is left for the user.
 *
 *	The simplest example might be something like:
 *
 *	ISR(SPIn_INT_vect)
 *	{
 *		// Get received data. 
 *		<spiSlave>.RxData[<spiSlave>.RxQnow++] = <spiSlave>.module->DATA;	
 *	}
 *
 *	where <spiSlave> and SPIn_INT_vect are appropriate to the slave instance.
 */

// branch to processor-appropriate header to implement function

/*! not as bad as the serial port configuration management...
 *	versions with 1 SPI port (B1, B3, E5 series):
 *		8E5, 16E5, 32E5 - SPIC; in avrxmega2								(config 1)
 *		64B1, 64B3 - SPIC; in avrxmega4
 *		128B1, 128B3 - SPIC; in avrxmega6
 *	
 *	versions with 2 SPI ports (A4(U), A3B(U), C3, C4, D3, & D4 series): 
 *		32C3, 16C4, 32C4, 32D3, 16D4, 32D4, 16A4(U), 32A4(U) 
 *			- SPIC & SPID; in avrxmega2 									(config 2)
 *		64C3, 64D3, 64D4, 64A4U - SPIC & SPID; in avrxmega4 
 *		128C3, 192C3, 256C3, 384C3, 128D4, 128D3, 192D3, 256D3, 384D3,  
 *			256A3B(U) - SPIC & SPID; in avrxmega6
 *		128A4U - SPIC & SPID; in avrxmega7
 *		
 *	versions with 3 SPI ports (A3 & A3U series):
 *		64A3(U) - SPIC, SPID, SPIE; in avrxmega4							(config 3)
 *		128A3(U), 192A3(U), 256A3(U) - SPIC, SPID, SPIE; in avrxmega6
 *
 *	versions with 4 SPI ports (A1 & A1U series):
 *		64A1(U) - SPIC, SPID, SPIE, & SPIF; in avrxmega5					(config 4)
 *		128A1(U) - SPIC, SPID, SPIE, & SPIF; in avrxmega7
 *		
 */

// the only thing that really changes is the specific registers that are mapped
// it appears all the Xmega series preserve the basic register setup and functionality
// so we only need to assign the specific registers to the generic USART port, and 
// then all the other library functions will work fine

// now branch by series-specific headers to map USART registers
// Atmel freakish toadspawn lobotomized toolchain implementation doesn't allow
// line continuation via \ when comments are present!

#if !defined (_AVRX_LIBRARY_BUILD) // prevent branching when compiling generic functions

// need prototype definition first

int8_t assign_SPIMaster_regs(SPI_Master_t *, uint8_t);
int8_t assign_SPISlave_regs(SPI_Slave_t *, uint8_t);

					// B1 series - config 1
					// B3 series - config 1
					// E5 series - config 1
#if (defined(__AVR_ATxmega64B1__) || defined(__AVR_ATxmega128B1__) \
	|| defined(__AVR_ATxmega64B3__) || defined(__AVR_ATxmega128B3__) \
	|| defined(__AVR_ATxmega8E5__) || defined(__AVR_ATxmega16E5__) || defined(__AVR_ATxmega32E5__))
	
int8_t assign_SPIM_regsX1(SPI_Master_t *, uint8_t);
int8_t assign_SPIS_regsX1(SPI_Slave_t *, uint8_t);
#define assign_SPIMaster_regs(a, b)	assign_SPIM_regsX1(a, b)
#define assign_SPISlave_regs(a, b)	assign_SPIS_regsX1(a, b)

					// A4 series - config 2
					// C3 series - config 2
					// C4 series - config 2
					// D3 series - config 2
					// D4 series - config 2
#elif (defined(__AVR_ATxmega16A4__) || defined(__AVR_ATxmega32A4__) \
	|| defined(__AVR_ATxmega16A4U__) || defined(__AVR_ATxmega32A4U__) \
	|| defined(__AVR_ATxmega64A4U__) || defined(__AVR_ATxmega128A4U__) \
	|| defined(__AVR_ATxmega32C3__) || defined(__AVR_ATxmega64C3__) \
	|| defined(__AVR_ATxmega128C3__) || defined(__AVR_ATxmega192C3__) \
	|| defined(__AVR_ATxmega256C3__) || defined(__AVR_ATxmega384C3__) \
	|| defined(__AVR_ATxmega16C4__) || defined(__AVR_ATxmega32C4__) \
	|| defined(__AVR_ATxmega32D3__) || defined(__AVR_ATxmega64D3__) \
	|| defined(__AVR_ATxmega128D3__) || defined(__AVR_ATxmega192D3__) \
	|| defined(__AVR_ATxmega256D3__) || defined(__AVR_ATxmega384D3__) \
	|| defined(__AVR_ATxmega16D4__) || defined(__AVR_ATxmega32D4__) \
	|| defined(__AVR_ATxmega64D4__) || defined(__AVR_ATxmega128D4__))
	
int8_t assign_SPIM_regsX2(SPI_Master_t *, uint8_t);
int8_t assign_SPIS_regsX2(SPI_Slave_t *, uint8_t);
#define assign_SPIMaster_regs(a, b)	assign_SPIM_regsX2(a, b)
#define assign_SPISlave_regs(a, b)	assign_SPIS_regsX2(a, b)

	 				// A3 series - config 3
					// A3U series - config 3
 					// A3B(U) series - config 3
#elif (defined(__AVR_ATxmega64A3__) || defined(__AVR_ATxmega128A3__) \
	|| defined(__AVR_ATxmega192A3__) || defined(__AVR_ATxmega256A3__) \
	|| defined(__AVR_ATxmega64A3U__) || defined(__AVR_ATxmega128A3U__) \
	|| defined(__AVR_ATxmega192A3U__) || defined(__AVR_ATxmega256A3U__) \
	|| defined (__AVR_ATxmega256A3B__) || defined (__AVR_ATxmega256A3BU__))
	
int8_t assign_SPIM_regsX3(SPI_Master_t *, uint8_t);
int8_t assign_SPIS_regsX3(SPI_Slave_t *, uint8_t);
#define assign_SPIMaster_regs(a, b)	assign_SPIM_regsX3(a, b)
#define assign_SPISlave_regs(a, b)	assign_SPIS_regsX3(a, b)

					// A1 series - config 4
 					// A1U series - config 4
#elif (defined(__AVR_ATxmega64A1__) || defined(__AVR_ATxmega128A1__) \
	|| defined (__AVR_ATxmega64A1U__) || defined (__AVR_ATxmega128A1U__))
	
int8_t assign_SPIM_regsX4(SPI_Master_t *, uint8_t);
int8_t assign_SPIS_regsX4(SPI_Slave_t *, uint8_t);
#define assign_SPIMaster_regs(a, b)	assign_SPIM_regsX4(a, b)
#define assign_SPISlave_regs(a, b)	assign_SPIS_regsX4(a, b)

#else
#  error "selected target is not in Xmega family"

#endif*/


#endif

#endif	// (_AVRX_LIBRARY_BUILD)


