/* This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief  XMEGA TWI driver header file.
 *
 *      This file contains the function prototypes and enumerator definitions
 *      for various configuration parameters for the XMEGA master TWI driver.
 *
 *      This driver is based on state machine logic for I2C (TWI).  The
 *      standard calls for the exchanges to proceed as follows:
 *
 *		Read data:
 *		Master		[S|ADDRx7|!W|   |REGx8|   |RS|ADDRx7|R|   |	      |ACK|       |NACK|P]
 *		Slave		[	  	    |ACK|     |ACK|  |        |ACK|DATA(0)|   |DATA(1)|    | ]
 *
 *
 *		Write data:
 *		Master		[S|ADDRx7|!W|   |REGx8|   |RS|ADDRx7|W|   |DATA(n)|   |P]
 *		Slave		[		    |ACK|     |ACK|  |        |ACK|	      |ACK| ]
 *
 *		Where:
 *			S = start condition
 *			ADDR = chip address (7 bits)
 *			W = write (0)
 *			R = read (1)
 *			REG = register address (8 bits)
 *			ACK = acknowledge bit (0)
 *			RS = repeated start
 *			DATA = data to read/write (n bytes)
 *			P = stop condition
 *
 *      In the XMega implementation, there are two signals that get used to coordinate
 *		transfers - TWIx_MASTER_STATUS register bit 7 for read (TWI_MASTER_RIF_bm) and bit
 *		6 for write (TWI_MASTER_WIF_bm). NOTE: the sequence of these signals relative to the
 *		above diagram is:
 *			
 *		Read data:
 *		Master		[S|ADDRx7|!W|   |REGx8|   |RS|ADDRx7|R|   |	      |ACK|       |NACK|P]
 *		Slave		[	  	    |ACK|     |ACK|  |        |ACK|DATA(0)|   |DATA(1)|    | ]
 *		WIF							1		  1				  0		  0           0    ?
 *		RIF							0		  0				  1	      1			  1    ?
 *		State		  START		    ADDR_ACK      REP_START	  ADDR_ACK			  DATA_ACK
 *
 *		Write data:
 *		Master		[S|ADDRx7|!W|   |REGx8|   |W|DATA(n)|   |P]
 *		Slave		[		    |ACK|     |ACK|         |ACK| ]
 *		WIF							1		  1			1	
 *		RIF							0		  0			0
 *		State		  START		    ADDR_ACK  REG_ACK	DATA_ACK
 *
 *		The software needs to handle repeated interrupts of the same type differently, as
 *		well as things like bus contention or other errors.  This is why a state machine for
 *		an interrupt-driven system is the logical construct.  This driver handles only 
 *		single-byte (8-bit) register addressing.
 *
 *		NOTE: Atmel interrupt signaling structure is VERY FINICKY about when data gets 
 *		set and is valid.  If you use the interrupt versions of the transaction functions,
 *		you ABSOLUTELY MUST point the buffers to volatile data or THEY WILL CONTAIN GARBAGE.
 *
 * \author
 *      California Optical Engineering: http://www.calopten.com \n
  *
 * $Revision: 1.0 $
 * $Date: 2015-01-31  $  \n
 *
 ******************************************************************************/
#ifndef AVRX_TWIM_H
#define AVRX_TWIM_H

#include <avr/io.h>
#include <stdlib.h>

#define TWI_SEND_ACK			0x03
#define TWI_SEND_NACK			0x07
#define TWI_SEND_COMP			0x02

#define TWI_MAX_BUF				8
#define TWI_MAX_ITER			1500		// timeout in clock cycles

// Transaction result enumeration
typedef enum TWI_RESULT_enum {
	TWI_RESULT_NULL, 
	TWI_RESULT_UNKNOWN, 
	TWI_RESULT_OK,
	TWI_RESULT_ERROR,
	TWI_RESULT_BAUDERROR,
	TWI_RESULT_NOPORT,
	TWI_RESULT_BUSY, 
	TWI_RESULT_BUFFER_OVERFLOW,
	TWI_RESULT_ARBITRATION_LOST, 
	TWI_RESULT_BUS_ERROR,
	TWI_RESULT_NACK_RECEIVED,
	TWI_RESULT_TRANSMIT_COLLISION,
	TWI_RESULT_ABORTED,
	TWI_RESULT_STOPPED,
	TWI_RESULT_FAIL,
} TWI_RESULT_t;

typedef enum TWI_STATE_enum {
	TWI_IDLE,
	TWI_START,
	TWI_ADDR_ACK,
	TWI_REG_ACK,
	TWI_REP_START,
	TWI_DATA_DONE,
	TWI_DONE,
	TWI_DATA_ACK,
	TWI_SLAVE_NACK,
	TWI_BUS_ERROR,
	TWI_ARB_LOST,
	TWI_REALLY_SCREWY_ERROR,
} TWI_STATE_t;

typedef enum TWI_BAUD_enum {
	TWI_100k,
	TWI_400k,
} TWI_BAUD_t;

typedef enum TWI_PORT_enum {
	_TWI_PORTC,
	_TWI_PORTD,
	_TWI_PORTE,
	_TWI_PORTF,
} TWI_PORT_t;

/*! \brief TWI master struct
 *
 *  TWI master struct. Holds pointer to TWI module,
 *  buffers and necessary variables.
 */
typedef struct TWI_Master {
	register8_t *rDATA, *rSTATUS;				//!< \brief SPI register addresses 
	register8_t *rCTRLA, *rCTRLB, *rCTRLC, *rBAUD, *rADDR;				//!< \brief SPI register addresses 
	volatile TWI_STATE_t twiState;				//!< State machine variable 
	volatile uint8_t address;					//!< Slave address
	volatile uint8_t regaddr;					//!< Slave target register address
	volatile uint8_t regread;					//!< Indicates whether register is being read (1) or written (0)
	volatile uint8_t *Tx;  						//!< Data to write
	volatile uint8_t *Rx;    					//!< Read data
	volatile uint8_t bytesToWrite;				//!< Number of bytes to write 
	volatile uint8_t bytesToRead;				//!< Number of bytes to read 
	volatile uint8_t bytesWritten;				//!< Number of bytes written 
	volatile uint8_t bytesRead;					//!< Number of bytes read 
} TWI_Master_t;


/*! \brief Initialize the TWI master module.
 *
 *  TWI master initialization function.
 *  Enables master read and write interrupts.
 *  Remember to enable interrupts globally from the main application.
 *
 *  \param twi                      The TWI_Master_t struct instance.
 *  \param twiPort                  Which TWI port to use (see enum).
 *  \param intLevel                 Master interrupt level.
 *	\param sysClk					The system clock speed.
 *  \param baudRate  				The desired baud rate.
 */
TWI_RESULT_t TWIM_Init(TWI_Master_t *twi, TWI_PORT_t twiPort, TWI_MASTER_INTLVL_t intLevel, uint32_t sysClk, TWI_BAUD_t baudRate);
	
/*! \brief TWI master write transaction (interrupt).
 *
 *  This function initiates an interrupt-driven write transaction
 *
 *  \param twi          The TWI_Master_t struct instance.
 *  \param address      Slave address.
 *  \param tx			Pointer to data to write (user must allocate memory VOLATILE)
 *  \param bytesToWrite Number of data bytes to write.
 *
 */
TWI_RESULT_t TWIM_WriteRegister(TWI_Master_t *twi, uint8_t address, uint8_t *tx, uint8_t bytesToWrite);

/*! \brief TWI master write transaction (transceived).
 *
 *  This function initiates a transceived write transaction
 *
 *  \param twi          The TWI_Master_t struct instance.
 *  \param address      Slave address.
 *  \param tx			Pointer to data to write (user must allocate memory VOLATILE)
 *  \param nBytes		Number of data bytes to write.
 *
 */
TWI_RESULT_t TWIM_WriteRegBytes(TWI_Master_t *twi, uint8_t address, uint8_t regaddr, uint8_t *tx, uint8_t nBytes);

/*! \brief TWI master read transaction (interrupt).
 *
 *  This function initiates an interrupt-driven TWI register read
 *
 *  \param twi          The TWI_Master_t struct instance.
 *  \param address      The slave chip address.
 *  \param register     The desired starting register address.
 *  \param *rx			The buffer to read bytes into
 *  \param bytesToRead  The number of bytes to read.
 *						If bytesToRead > rxBufSz the function will abort
 *						and set the result flag to indicate an overflow
 *
*/
TWI_RESULT_t TWIM_ReadRegister(TWI_Master_t *twi, uint8_t address, uint8_t regaddr, uint8_t *rx, uint8_t bytesToRead);

/*! \brief TWI master read transaction (transceived).
 *
 *  This function initiates a transceived TWI register read
 *
 *  \param twi          The TWI_Master_t struct instance.
 *  \param address      The slave chip address.
 *  \param register     The desired starting register address.
 *  \param *rx			The buffer to read bytes into
 *  \param nBytes		The number of bytes to read.
 *						If bytesToRead > rxBufSz the function will abort
 *						and set the result flag to indicate an overflow
 *
*/
TWI_RESULT_t TWIM_ReadRegBytes(TWI_Master_t *twi, uint8_t address, uint8_t regaddr, uint8_t *rx, uint8_t nBytes);

	
/*! \brief Common TWI master interrupt service routine.
 *
 *  Check current status and calls the appropriate handler.
 *
 *  \param twi  The TWI_Master_t struct instance.
 */
void TWIM_Handler(TWI_Master_t *twi);

/*! TWI master interrupt service routine.
 *
 *  Interrupt service routine for the TWI master. Copy the needed vectors
 *  into your code.
 *	
 *	\param TWIn_TWIM_vect	Appropriate TWIM_vect for the port used
 *							(e.g. master on PORTC = TWIC_TWIM_vect)
 *	\param <twiMaster>		Name of TWI Master instance
 *							(note: MUST be instantiated, NOT TWI_Master_t *twiMaster)
 *
 *   ISR(TWIn_TWIM_vect)
 *   {
 *     TWIM_Handler(&\<twiMaster\>);
 *   }
 *
 */


#endif /* AVRX_TWIM_H */
