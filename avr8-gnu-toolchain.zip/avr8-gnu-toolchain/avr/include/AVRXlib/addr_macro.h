#ifndef _ADDR_MACRO_H
#define _ADDR_MACRO_H

#define _READ_SFR8(addr)	(*(volatile uint8_t *)(addr))
#define _SET_SFR8(addr)  *((volatile uint8_t *)(addr))
#define _GET_ADDR8(reg)	(uint16_t)((volatile uint8_t *)(&(reg)))

#define _READ_SFR16(addr)	(*(volatile uint16_t *)(addr))
#define _SET_SFR16(addr)  *((volatile uint16_t *)(addr))
#define _GET_ADDR16(reg)	(uint16_t)((volatile uint16_t *)(&(reg)))


#endif
